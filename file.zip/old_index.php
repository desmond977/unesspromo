<?php
header("Location: https://shopextv.com/");

?>